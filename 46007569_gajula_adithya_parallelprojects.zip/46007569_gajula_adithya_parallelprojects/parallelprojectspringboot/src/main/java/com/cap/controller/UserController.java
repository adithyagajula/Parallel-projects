package com.cap.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entity.BankEntity;
import com.cap.entity.TransactionEntity;
import com.cap.exception.DataNotFoundException;
import com.cap.service.IBankService;

@RestController
@RequestMapping("/xyzbank")
public class UserController {
	@Autowired
	IBankService bankserviceobject;

	@PostMapping(value = "/adddetails")
	long Creation(@Valid @RequestBody  BankEntity bankbean) {
		return  bankserviceobject.Creation(bankbean);
	}
	
	@GetMapping
	@RequestMapping("/showbalance/{accountnumber}")
	int showbalance(@PathVariable long accountnumber) throws DataNotFoundException
	{
		return  bankserviceobject.showbalance(accountnumber);
	}
	
	@PutMapping
	@RequestMapping("/deposit/{accountnumber}/{depositamount}")
	int deposit(@PathVariable long accountnumber,@PathVariable int depositamount) throws DataNotFoundException
	{
		return bankserviceobject.deposit(accountnumber,depositamount);
		
	}
	@PutMapping
	@RequestMapping("/withdraw/{accountnumber}/{withdrawamount}")
	int withdraw(@PathVariable long accountnumber,@PathVariable int withdrawamount) throws DataNotFoundException
	{
		return bankserviceobject.withdraw(accountnumber,withdrawamount);
		
	}
	@PutMapping
	@RequestMapping("/fundtransfer/{accountnumber1}/{accountnumber2}/{fundamount}")
	int fundtransfer(@PathVariable long accountnumber1,@PathVariable long accountnumber2,@PathVariable int fundamount) throws DataNotFoundException
	{
		return bankserviceobject.fundtransfer(accountnumber1,accountnumber2,fundamount);
		
	}
	
	@GetMapping
	@RequestMapping("/printtransaction/{accountnumber}")
	List<TransactionEntity> printtransaction(@PathVariable long accountnumber) throws DataNotFoundException
	{
		return bankserviceobject.printtransaction(accountnumber);
		
	}
}


//{"bname":"Adithya",
//"bnum2":"8179700938",
//"bdob":"07/05/1998",
//"bpass":"adithya123",
// "bbal":1200,
//"actype":"Savings",
//"location":"Hyderabad"}