import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';
import { Router } from '@angular/router';
import { transactiondetails } from 'src/app/model/Transaction';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
 
  router:Router;
  transactionObj:transactiondetails[]=[];
  servicelayer:ServicelayerService;
  constructor(servicelayer:ServicelayerService,router:Router) {
    this.servicelayer= servicelayer,this.router=router}

  transaction(data:any)
  {
 let a=   this.servicelayer.transaction(data.accountnumber,data.password)
    a.subscribe((data) =>{
      let trans
      for(let a of data){
        console.log(a)
         trans = new transactiondetails(a.transId,a.baccInitial,a.baccFinal,a.transMetd,a.transBal,a.transdate)
         this.transactionObj.push(trans);
      }
      console.log(trans)
    },(error) =>{
      alert("enter correct details")
      this.router.navigate(['useraction']);
    })
  }
  ngOnInit() {
  }

}
