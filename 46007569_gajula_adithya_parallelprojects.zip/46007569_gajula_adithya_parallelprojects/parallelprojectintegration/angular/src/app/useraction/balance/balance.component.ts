import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {
servicelayer:ServicelayerService; 
router:Router;
  constructor(servicelayer:ServicelayerService,router:Router) {
    this.servicelayer= servicelayer,
    this.router=router
  }

  showbalance(data:any)
  {
 let a =   this.servicelayer.showbalance(data.accountnumber,data.password);
 a.subscribe((data) =>{
  alert("Account balance is "+data);
  this.router.navigate(['useraction']);
},(error) =>{
  alert("enter correct details")
  this.router.navigate(['useraction']);
})
  }
  ngOnInit() {
  }

}
